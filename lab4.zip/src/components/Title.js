import React from "react";

export default function Title(){
    return (
        <div className="title">
            <h1>My TODO App</h1>
        </div>
    );
}